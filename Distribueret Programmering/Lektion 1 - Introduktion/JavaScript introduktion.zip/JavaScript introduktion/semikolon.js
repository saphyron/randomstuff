// semikolon.js
let
    x =
    123
console.
log
(x)