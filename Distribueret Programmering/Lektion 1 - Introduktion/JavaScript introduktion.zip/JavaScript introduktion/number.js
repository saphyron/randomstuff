// number.js
console.log(1 == 1.0); // => true
console.log(7.0/2.0);// => 3.5
console.log(7/2); // => 3.5
console.log(Math.trunc(7/2)); // => 3
console.log(7/'two'); // => NaN
console.log(7/0); // => Infinity
