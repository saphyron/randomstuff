// omgivelse.js
NaN;
parseInt;
console;
Number;
Math;

console.log(NaN); // => NaN
console.log(parseInt('111', 2)); // => 7
console.log(Number('0xFF')); // => 255
console.log(Number.isNaN('1o2')); // => false
console.log(Math.cos(Math.PI)); // => -1
