// typekonvertering.js
console.log(true + 2); // => 3
console.log('3' + 4); // => 34
console.log('3' - 4); // => -1
console.log(5 * '6'); // => 30
console.log(7 * null); // => 0
console.log('x' - 8); // => NaN
console.log(!'ok' + 9); // => 9

