// falsy-truthy.js
let i = 2;
while (i--)
    console.log(i); // => 1 0
