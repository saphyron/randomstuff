// boolsk.js
console.log('abc' && 123); // => 123
console.log('abc' || 123); // => abc
console.log(!'abc'); // => false
console.log(!0); // => true

